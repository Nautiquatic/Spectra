// Kill Counter: an example Spectra code mod for Prismfall.
// SpectraMods.api is the game (see mod-sdk/README.md); SpectraMods.on listens for events.
(function () {
  const api = SpectraMods.api;
  let kills = 0;
  SpectraMods.on('runStart', (run) => { kills = 0; api.announce('Kill Counter is on · ' + run.class, '#ffd166'); });
  SpectraMods.on('kill', () => { kills += 1; if (kills % 100 === 0) api.announce(kills + ' hostiles down', '#7dffb0'); });
  window.__killCounter = () => kills; // for testing
})();
