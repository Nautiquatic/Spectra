@echo off
setlocal
set "NOVA_JAVA=java.exe"
if defined JAVA_HOME set "NOVA_JAVA=%JAVA_HOME%\bin\java.exe"
"%NOVA_JAVA%" -jar "%~dp0gradle\wrapper\gradle-wrapper.jar" %*
exit /b %ERRORLEVEL%
