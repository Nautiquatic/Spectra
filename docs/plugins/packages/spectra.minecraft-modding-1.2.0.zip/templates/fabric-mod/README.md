# Fabric 1.21.1

Fabric mod for Minecraft 1.21.1.

Use JDK 21 and set JAVA_HOME to its installation folder. The first build downloads Gradle and the game's development dependencies.

- In Spectra IDE, open the Java entry point and press F5 to run the development client.
- In Spectra IDE's Gradle panel, choose Build to create the mod JAR in `build/libs`.
- From a terminal use `gradlew.bat runClient` on Windows or `sh ./gradlew runClient` on macOS and Linux. Replace `runClient` with `build` to build the JAR.
