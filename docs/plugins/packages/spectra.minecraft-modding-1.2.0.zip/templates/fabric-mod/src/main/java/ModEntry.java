package {{package_name}};

import net.fabricmc.api.ModInitializer;

public final class ModEntry implements ModInitializer {
    @Override
    public void onInitialize() {
        // Register your mod content here.
    }
}
