const button = document.querySelector("button");
const greeting = document.querySelector("[role=status]");

button.addEventListener("click", () => {
    greeting.textContent = "Hello from Spectra!";
});
