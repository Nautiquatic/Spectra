# Static Web Starter

Open `index.html` in a browser or press F5 in Spectra.
