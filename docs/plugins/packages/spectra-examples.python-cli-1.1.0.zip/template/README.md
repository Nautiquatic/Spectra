# Python CLI Starter

Run `python main.py Ada` or press F5 in Spectra with `main.py` open.
