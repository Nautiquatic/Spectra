local M = {}

function M.message(name)
    return "Hello, " .. name .. "!"
end

return M
