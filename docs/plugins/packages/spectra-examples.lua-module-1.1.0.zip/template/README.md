# Lua Module Starter

Run `lua main.lua Ada` or press F5 in Spectra with `main.lua` open.
