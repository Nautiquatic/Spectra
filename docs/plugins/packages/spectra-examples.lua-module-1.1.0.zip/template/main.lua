local greeting = require("greeting")

print(greeting.message(arg[1] or "Spectra"))
